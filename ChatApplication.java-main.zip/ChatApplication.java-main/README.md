# ChatApplication.java
this a a chat application project in java
